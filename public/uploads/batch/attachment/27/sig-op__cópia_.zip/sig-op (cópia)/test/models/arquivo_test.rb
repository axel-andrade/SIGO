require 'test_helper'

class ArquivoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
