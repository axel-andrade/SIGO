class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  helper_method :buscarDBF
  helper_method :buscarSQL
  helper_method :pegar_ultimo
  
  #helper_method permita que chame alguma action selecionada na view 
  
  def pegar_ultimo(tipo,opcao)

    if opcao==1
      
        @ultimoregistro = Search.last #pega ultimo registro da tabela 

        tipo.each do |search|
          if search == @ultimoregistro 
           @auxiliar = search.tipo_via + "," + search.logradouro + "," + search.numero + "," + search.bairro
          end
        end

        return @auxiliar

    else

       @ultimoregistro = Batch.last 

       tipo.each do |batch|
          if batch == @ultimoregistro 
           @auxiliar = batch.attachment
          end
       end

       return @auxiliar 

    end 

      

      #render html: @auxiliar # render html: @variavel exibi na tela o conteudo da sua variavel
      
  end 

  def buscarSQL#(endereco)
      
      #if endereco != nil

          #@vetor = endereco.split(",")
          
          cont = 0

          #my = Mysql.new(hostname, username, password, databasename)  
          con = Mysql.new('localhost', 'root', 'root', 'teste')
          record = con.query('select * from contatos')
          record.each_hash { |h| @aux = h['nome'] }#h['longitudex']+ ' '+ h['latitudey']} 
          
          return @aux
      #end

      #my = Mysql.new(hostname, username, password, databasename)  
      #con = Mysql.new('localhost', 'root', 'root', 'teste')  
      #rs = con.query('select * from contatos')  
      #rs.each_hash { |h| @aux =  h['nome']+ ' '+ h['telefone']} 
      #con.close   

      #return @aux
  end 

  def buscarDBF(endereco,metodo)

      if endereco != nil
          
          n = 0

          if metodo == 2 
              n = -1 #pesquisa unitaria esta com elementos a mais no vetor, corrigi depois tirando o tipo_via(refazendo o scaffold)
          end 
        
          @vetor = endereco.split(",")
                
          encontrou = 0 

          enderecos = DBF::Table.new("lib/dbf/UH_nov_2012_pt.dbf")

          enderecos.find(:all,logradouro: @vetor[n+1].strip.upcase, numero: @vetor[n+2].strip.upcase, bairro: @vetor[n+3].strip.upcase) do |record|  #usando find com os parametros para encontrar o endereco exatos
            
              if record  #se foi encontrado o endereco return latitude e longitude pu escreve em um tabela xls
                 
                 @resultado = "Logintude : "+record.longitudex+"       Latitude: "+record.latitudey
                 encontrou = 1
                 #Search.destroy
                 break #se os enderecos sao todos diferentes nao ha necessidade de percorrer mais depois de encontrado
              
              end 

          end

          if encontrou == 1 
             return @resultado
          else 
             return  "Não foi possivel encontrar este endereço."
          end 
      else 
          return "Endereco nao cadastrado ou invalido"
      end

  end

end
