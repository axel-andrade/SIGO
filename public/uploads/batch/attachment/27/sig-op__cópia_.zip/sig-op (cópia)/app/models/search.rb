class Search < ApplicationRecord
  
  validates :tipo_via,:logradouro,:numero,:bairro, presence: true 
  
end
