class BatchesController < ApplicationController
  helper_method :buscar_planilha
  
  def index
      @batches = Batch.all  
  end

  def download
    send_file "#{Rails.root}/public/#{params[:file_name]}"
  end
  
  def buscar_planilha(diretorio)
    
    @aux = diretorio.to_s

    if @aux.index(/.xls/) != nil

    	render html: @aux
        
	    planilha = Spreadsheet.open 'public'+@aux #/uploads/batch/attachment/8/endereco.xls' # Abrindo a planilha
	
	    sheet1 = planilha.worksheet 0 # Especificando uma única planilha por índice
		
		arquivo = File.new("/home/axel/Área de Trabalho/resultado.csv","w")

		sheet1.each do |row|
           
           row[0] = row[0].upcase

           #retirando strings "ruas" e "avenidas" da planilha

           if row[0].index(/RUA /)!=nil
           	  row[0].slice! "RUA "
           elsif row[0].index(/AVENIDA /) !=nil
           	   row[0].slice! "AVENIDA "
           elsif row[0].index(/AV. /)!=nil
           	   row[0].slice! "AV. "
           end 
         
           	
           @linha = row[0].to_s() +","+ row[1].to_s() +","+row[2].to_s() #juntando as colunas do excel
           @resultado = buscarDBF(@linha.to_s(),2) #enviando a linda para a funcao de busca e pegando o resultado
           
		   arquivo.write("#{row[0]} , #{row[1]}, #{row[2]}, #{@resultado}\n")
		end
        
		arquivo.close

	else 
	    render html: "Arquivo invalido"
    end
  end 

  def new
      @batch = Batch.new
  end
   
  def create
      @batch = Batch.new(resume_params)
      
      if @batch.save
         redirect_to batches_path, notice: "The resume #{@batch.name} has been uploaded."
      else
         render "new"
      end
      
  end
   
  def destroy
      @batch = Batch.find(params[:id])
      @batch.destroy
      redirect_to batches_path, notice:  "The resume #{@batch.name} has been deleted."
  end
   
   private
      def resume_params
      params.require(:batch).permit(:name, :attachment)
   end

end
